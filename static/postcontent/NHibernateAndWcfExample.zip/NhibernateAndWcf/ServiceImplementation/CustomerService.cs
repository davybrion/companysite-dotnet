﻿using System;
using System.Collections.Generic;

using NHibernate;
using NHibernate.Cfg;

using Northwind.Domain.Entities;

using ServiceInterface;

namespace ServiceImplementation
{
	public class CustomerService : ICustomerService
	{
		private static readonly ISessionFactory _sessionFactory;

		static CustomerService()
		{
			try
			{
				Configuration configuration = new Configuration().AddAssembly("Northwind.Domain");
				_sessionFactory = configuration.BuildSessionFactory();
			}
			catch (Exception e)
			{
				Console.Write(e);
				throw;
			}
		}

		public IList<Customer> GetCustomersWithTheirOrders()
		{
			using (ISession session = _sessionFactory.OpenSession())
			{
				return session.CreateCriteria(typeof(Customer))
					.SetFetchMode("Orders", FetchMode.Join)
					.SetResultTransformer(CriteriaUtil.DistinctRootEntity)
					.List<Customer>();
			}
		}

		public void PersistCustomer(Customer customer)
		{
			using (ISession session = _sessionFactory.OpenSession())
			{
				using (ITransaction transaction = session.BeginTransaction())
				{
					session.SaveOrUpdate(customer);
					session.Flush();
					transaction.Commit();
				}
			}
		}
	}
}
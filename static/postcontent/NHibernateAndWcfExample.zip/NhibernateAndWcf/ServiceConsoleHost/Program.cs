﻿using System;
using System.ServiceModel;

using ServiceImplementation;

namespace ServiceConsoleHost
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			using (ServiceHost host = new ServiceHost(typeof(CustomerService)))
			{
				host.Open();

				Console.WriteLine("press ENTER to quit");
				Console.ReadLine();
			}
		}
	}
}
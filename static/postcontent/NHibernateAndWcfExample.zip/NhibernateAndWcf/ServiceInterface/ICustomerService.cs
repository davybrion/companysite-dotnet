﻿using System.Collections.Generic;
using System.ServiceModel;

using Northwind.Domain.Entities;

namespace ServiceInterface
{
	[ServiceContract]
	public interface ICustomerService
	{
		[UseNetDataContractSerializer]
		[OperationContract]
		IList<Customer> GetCustomersWithTheirOrders();

		[UseNetDataContractSerializer]
		[OperationContract]
		void PersistCustomer(Customer customer);
	}
}
﻿using System.Collections.Generic;
using System.ServiceModel;

using Northwind.Domain.Entities;

using ServiceInterface;

namespace ServiceClient
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			ChannelFactory<ICustomerService> factory = new ChannelFactory<ICustomerService>("CustomerServiceEndPoint");
			ICustomerService proxy = factory.CreateChannel();
			IList<Customer> customers = proxy.GetCustomersWithTheirOrders();
		}
	}
}
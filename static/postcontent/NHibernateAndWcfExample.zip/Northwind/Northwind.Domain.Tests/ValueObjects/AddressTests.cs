using Northwind.Domain.ValueObjects;
using NUnit.Framework;

namespace Northwind.Domain.Tests.ValueObjects
{
	[TestFixture]
	public class AddressTests
	{
		private readonly string _defaultStreet = "MyStreet 243";
		private readonly string _defaultCity = "MyCity";
		private readonly string _defaultRegion = "MyRegion";
		private readonly string _defaultPostalCode = "12345";
		private readonly string _defaultCountry = "MyCountry";
		private readonly string _defaultPhoneNumber = "123-4567-89";
		private readonly string _defaultFax = "MyFax";

		private Address CreateTestAddressWithDefaultData()
		{
			return new Address(_defaultStreet, _defaultCity, _defaultRegion,
			                   _defaultPostalCode, _defaultCountry, _defaultPhoneNumber, _defaultFax);
		}

		[Test]
		public void NullAddressReferenceDoesntCrashWhenUsingEqualityOperator()
		{
			Address address1 = null;
			Address address2 = CreateTestAddressWithDefaultData();

			Assert.That(address1 != address2);
		}

		[Test]
		public void TwoInstancesWithDifferentDataAreNotEqual()
		{
			Address address1 = CreateTestAddressWithDefaultData();
			Address address2 = new Address(_defaultStreet + "2", _defaultCity, _defaultRegion,
			                               _defaultPostalCode, _defaultCountry, _defaultPhoneNumber, _defaultFax);

			Assert.AreNotEqual(address1, address2);
			Assert.That(address1 != address2);
		}

		[Test]
		public void TwoInstancesWithDifferentDataDoNotReturnSameHashCode()
		{
			Address address1 = CreateTestAddressWithDefaultData();
			Address address2 = new Address(_defaultStreet + "2", _defaultCity, _defaultRegion,
			                               _defaultPostalCode, _defaultCountry, _defaultPhoneNumber, _defaultFax);

			Assert.AreNotEqual(address1.GetHashCode(), address2.GetHashCode());
		}

		[Test]
		public void TwoInstancesWithSameDataAreEqual()
		{
			Address address1 = CreateTestAddressWithDefaultData();
			Address address2 = CreateTestAddressWithDefaultData();

			Assert.AreEqual(address1, address2);
			Assert.That(address1 == address2);
		}

		[Test]
		public void TwoInstancesWithSameDateReturnSameHashCode()
		{
			Address address1 = CreateTestAddressWithDefaultData();
			Address address2 = CreateTestAddressWithDefaultData();

			Assert.AreEqual(address1.GetHashCode(), address2.GetHashCode());
		}
	}
}
using System;
using NHibernate;
using Northwind.Domain.Entities;
using Northwind.Domain.ValueObjects;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class EmployeeTests : NHibernateTest
	{
		private void CreateEmployeeWithOrder(ISession session, ref long employeeId,
		                                     ref long orderId)
		{
			Customer customer = new Customer("MyCustomer");
			Order order = new Order(customer);

			Employee employee = new Employee("FirstName", "LastName");
			employee.AddOrder(order);

			session.Save(customer);
			session.Save(employee);
			session.Flush();

			employeeId = employee.Id;
			orderId = order.Id;

			session.Evict(customer);
			session.Evict(order);
			session.Evict(employee);
		}

		private void CreateEmployeeWithTerritory(ISession session, ref long employeeId,
		                                         ref long territoryId)
		{
			Region region = new Region("MyRegion");
			Territory territory = new Territory("MyTerritory");
			territory.Region = region;

			Employee employee = new Employee("Test", "Test");
			territory.AddEmployee(employee);

			session.Save(region);
			session.Save(territory);
			session.Flush();

			employeeId = employee.Id;
			territoryId = territory.Id;

			session.Evict(region);
			session.Evict(territory);
			session.Evict(employee);
		}

		private void CreateEmployeeWithSubordinate(ISession session,
		                                           ref long superiorId, ref long subordinateId)
		{
			Employee superior = new Employee("The", "Superior");
			Employee subordinate = new Employee("The", "Subordinate");

			superior.AddSubordinate(subordinate);

			session.Save(superior);
			session.Flush();

			superiorId = superior.Id;
			subordinateId = subordinate.Id;

			session.Evict(superior);
			session.Evict(subordinate);
		}

		[Test]
		public void CreateEmployeeWithAllData()
		{
			Address address = new Address("street", "city", "region", "postal", "country",
			                              "phone", null);
			DateTime birthDate = new DateTime(1981, 6, 19);
			string extension = "blah";
			string firstName = "Davy";
			DateTime hireDate = DateTime.Today;
			string lastName = "Brion";
			string notes = "a;dkjfa;dkfja;kdfja;kdfjqeriuadkjf;j";
			string title = "developer";
			string titleOfCourtesy = "Mr.";

			Employee employee = new Employee();
			employee.Address = address;
			employee.BirthDate = birthDate;
			employee.Extension = extension;
			employee.FirstName = firstName;
			employee.HireDate = hireDate;
			employee.LastName = lastName;
			employee.Notes = notes;
			employee.Title = title;
			employee.TitleOfCourtesy = titleOfCourtesy;

			Session.Save(employee);
			Session.Flush();

			long employeeId = employee.Id;

			Session.Evict(employee);

			employee = Session.Get<Employee>(employeeId);
			Assert.AreEqual(address, employee.Address);
			Assert.AreEqual(birthDate, employee.BirthDate);
			Assert.AreEqual(extension, employee.Extension);
			Assert.AreEqual(firstName, employee.FirstName);
			Assert.AreEqual(hireDate, employee.HireDate);
			Assert.AreEqual(lastName, employee.LastName);
			Assert.AreEqual(notes, employee.Notes);
			Assert.AreEqual(title, employee.Title);
			Assert.AreEqual(titleOfCourtesy, employee.TitleOfCourtesy);
		}

		[Test]
		public void CreateEmployeeWithLinkedOrder()
		{
			long employeeId = -1;
			long orderId = -1;

			CreateEmployeeWithOrder(Session, ref employeeId, ref orderId);

			Employee employee = Session.Get<Employee>(employeeId);
			Order order = Session.Get<Order>(orderId);

			Assert.That(employee.Orders.Contains(order));
			Assert.AreEqual(employee, order.Employee);
		}

		[Test]
		public void CreateEmployeeWithLinkedSubordinate()
		{
			long superiorId = -1;
			long subordinateId = -1;

			CreateEmployeeWithSubordinate(Session, ref superiorId, ref subordinateId);

			Employee superior = Session.Get<Employee>(superiorId);
			Employee subordinate = Session.Get<Employee>(subordinateId);

			Assert.That(superior.Subordinates.Contains(subordinate));
			Assert.AreEqual(superior, subordinate.Superior);
		}

		[Test]
		public void CreateEmployeeWithLinkedTerritory()
		{
			long employeeId = -1;
			long territoryId = -1;

			CreateEmployeeWithTerritory(Session, ref employeeId, ref territoryId);

			Employee employee = Session.Get<Employee>(employeeId);
			Territory territory = Session.Get<Territory>(territoryId);

			Assert.That(employee.Territories.Contains(territory));
			Assert.That(territory.Employees.Contains(employee));
		}

		[Test]
		public void DeleteEmployeeLinkedToTerritory()
		{
			long territoryId = -1;
			long employeeId = -1;

			CreateEmployeeWithTerritory(Session, ref employeeId, ref territoryId);

			Session.Delete("from Employee where EmployeeId = ?", employeeId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.AreEqual(0, Session.Get<Territory>(territoryId).Employees.Count);
		}

		[Test]
		public void DeleteEmployeeWithLinkedOrder()
		{
			long employeeId = -1;
			long orderId = -1;

			CreateEmployeeWithOrder(Session, ref employeeId, ref orderId);

			Session.Delete("from Employee where EmployeeId = ?", employeeId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Order>(orderId).Employee);
		}

		[Test]
		public void DeleteSuperiorWithLinkedSubordinate()
		{
			long superiorId = -1;
			long subordinateId = -1;

			CreateEmployeeWithSubordinate(Session, ref superiorId, ref subordinateId);

			Session.Delete("from Employee where EmployeeId = ?", superiorId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Employee>(subordinateId).Superior);
		}

		[Test]
		public void RemoveOrderFromEmployee()
		{
			long employeeId = -1;
			long orderId = -1;

			CreateEmployeeWithOrder(Session, ref employeeId, ref orderId);

			Employee employee = Session.Get<Employee>(employeeId);
			Order order = Session.Get<Order>(orderId);

			employee.RemoveOrder(order);

			Session.Update(employee);
			Session.Flush();

			Session.Evict(order);

			Assert.IsNull(Session.Get<Order>(orderId).Employee);
		}

		[Test]
		public void RemoveSubordinateFromEmployee()
		{
			long superiorId = -1;
			long subordinateId = -1;

			CreateEmployeeWithSubordinate(Session, ref superiorId, ref subordinateId);

			Employee superior = Session.Get<Employee>(superiorId);
			Employee subordinate = Session.Get<Employee>(subordinateId);

			superior.RemoveSubordinate(subordinate);

			Session.Update(superior);
			Session.Flush();

			Session.Evict(subordinate);

			Assert.IsNull(Session.Get<Employee>(subordinateId).Superior);
		}
	}
}
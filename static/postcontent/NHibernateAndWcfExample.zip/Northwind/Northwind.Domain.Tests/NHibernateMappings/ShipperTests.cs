using NHibernate;
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class ShipperTests : NHibernateTest
	{
		private void CreateShipperWithOrder(ISession session, ref long shipperId, ref long orderId)
		{
			Shipper shipper = new Shipper("MyShipper");

			Customer customer = new Customer("MyCustomer");
			Order order = new Order(customer);
			order.Shipper = shipper;

			session.Save(customer);
			session.Save(shipper);
			session.Save(order);
			session.Flush();

			shipperId = shipper.Id;
			orderId = order.Id;

			session.Evict(customer);
			session.Evict(order);
			session.Evict(shipper);
		}

		[Test]
		public void CreateShipper()
		{
			string testString = "blah";

			Shipper shipper = new Shipper();
			shipper.CompanyName = testString;
			shipper.PhoneNumber = testString;

			Session.Save(shipper);
			Session.Flush();

			long id = shipper.Id;

			Session.Evict(shipper);

			shipper = Session.Get<Shipper>(id);
			Assert.AreEqual(testString, shipper.CompanyName);
			Assert.AreEqual(testString, shipper.PhoneNumber);
		}

		[Test]
		public void DeleteShipperLinkedToAnOrder()
		{
			long shipperId = -1;
			long orderId = -1;

			CreateShipperWithOrder(Session, ref shipperId, ref orderId);

			Session.Delete("from Shipper where ShipperId = ?", shipperId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Order>(orderId).Shipper);
		}

		[Test]
		public void ShipperContainsLinkedOrders()
		{
			long shipperId = -1;
			long orderId = -1;

			CreateShipperWithOrder(Session, ref shipperId, ref orderId);

			Shipper shipper = Session.Get<Shipper>(shipperId);
			Order order = Session.Get<Order>(orderId);

			Assert.That(shipper.Orders.Contains(order));
			Assert.AreEqual(shipper, order.Shipper);
		}
	}
}
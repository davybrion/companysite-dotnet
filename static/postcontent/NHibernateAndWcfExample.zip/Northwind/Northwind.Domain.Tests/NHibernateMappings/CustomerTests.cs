using System.Collections;

using NHibernate;
using Northwind.Domain.Entities;
using Northwind.Domain.ValueObjects;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class CustomerTests : NHibernateTest
	{
		private void CreateCustomerWithOrder(ISession session, ref long customerId, ref long orderId)
		{
			Customer customer = new Customer("Customer");
			Order order = new Order();
			customer.AddOrder(order);

			session.Save(customer);
			session.Flush();

			customerId = customer.Id;
			orderId = order.Id;

			session.Evict(order);
			session.Evict(customer);
		}

		[Test]
		public void CreateCustomerWithAllData()
		{
			Address address = new Address("t", "t", "t", "t", "t", "t", "t");
			string testString = "test";

			Customer customer = new Customer();
			customer.Address = address;
			customer.CompanyName = testString;
			customer.ContactName = testString;
			customer.ContactTitle = testString;

			Session.Save(customer);
			Session.Flush();

			long id = customer.Id;

			Session.Evict(customer);

			customer = Session.Get<Customer>(id);
			Assert.AreEqual(address, customer.Address);
			Assert.AreEqual(testString, customer.CompanyName);
			Assert.AreEqual(testString, customer.ContactName);
			Assert.AreEqual(testString, customer.ContactTitle);
		}

		[Test]
		public void CreateCustomerWithLinkedOrder()
		{
			long customerId = -1;
			long orderId = -1;

			CreateCustomerWithOrder(Session, ref customerId, ref orderId);

			Customer customer = Session.Get<Customer>(customerId);
			Order order = Session.Get<Order>(orderId);

			Assert.That(customer.Orders.Contains(order));
			Assert.AreEqual(customer, order.Customer);
		}

		[Test]
		public void DeleteCustomerWithLinkedOrder()
		{
			long customerId = -1;
			long orderId = -1;

			CreateCustomerWithOrder(Session, ref customerId, ref orderId);

			Session.Delete("from Customer where CustomerId = ?", customerId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Order>(orderId));
		}

		[Test]
		public void RemoveLinkedOrderFromCustomer()
		{
			long customerId = -1;
			long orderId = -1;

			CreateCustomerWithOrder(Session, ref customerId, ref orderId);

			Customer customer = Session.Get<Customer>(customerId);
			Order order = Session.Get<Order>(orderId);

			customer.RemoveOrder(order);
			Session.Update(customer);
			Session.Flush();

			Session.Evict(customer);

			Assert.IsNull(Session.Get<Order>(orderId));
			Assert.AreEqual(0, Session.Get<Customer>(customerId).Orders.Count);
		}
	}
}
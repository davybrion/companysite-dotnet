using System;
using NHibernate;
using Northwind.Domain.Entities;
using Northwind.Domain.ValueObjects;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class OrderTests : NHibernateTest
	{
		private void CreateOrderWithOrderLines(ISession session, ref long orderId, ref long orderLineId)
		{
			Customer customer = new Customer("MyCustomer");
			Product product = new Product("MyProduct");

			Order order = new Order(customer);
			OrderLine orderLine = new OrderLine();
			orderLine.Product = product;
			orderLine.Discount = 1;
			orderLine.Quantity = 5;
			orderLine.UnitPrice = 4;

			order.AddOrderLine(orderLine);

			session.Save(customer);
			session.Save(product);
			session.Save(order);
			session.Flush();

			orderId = order.Id;
			orderLineId = orderLine.Id;

			session.Evict(customer);
			session.Evict(product);
			session.Evict(order);
			session.Evict(orderLine);
		}

		[Test]
		public void CreateOrder()
		{
			decimal freight = 187634.76M;
			DateTime orderDate = DateTime.Today;
			DateTime requiredDate = DateTime.Today;
			DateTime shippingDate = DateTime.Today;
			string shippedTo = "Me";

			Customer customer = new Customer("CustomerName");
			Employee employee = new Employee("FirstName", "SecondName");
			Shipper shipper = new Shipper("ShipperName");
			Address address = new Address("street", "city", "region", "postalcode", "country",
			                              null, null);

			Order order = new Order();
			order.Customer = customer;
			order.Employee = employee;
			order.Shipper = shipper;
			order.ShippingAddress = address;
			order.Freight = freight;
			order.OrderDate = orderDate;
			order.RequiredDate = requiredDate;
			order.ShippingDate = shippingDate;
			order.ShippedTo = shippedTo;

			Session.Save(customer);
			Session.Save(employee);
			Session.Save(shipper);
			Session.Save(order);
			Session.Flush();

			long orderId = order.Id;
			long shipperId = shipper.Id;
			long customerId = customer.Id;
			long employeeId = employee.Id;

			Session.Evict(order);
			Session.Evict(customer);
			Session.Evict(shipper);
			Session.Evict(employee);

			order = Session.Get<Order>(orderId);
			Assert.AreEqual(customerId, order.Customer.Id);
			Assert.AreEqual(employeeId, order.Employee.Id);
			Assert.AreEqual(shipperId, order.Shipper.Id);
			Assert.AreEqual(address, order.ShippingAddress);
			Assert.AreEqual(freight, order.Freight);
			Assert.AreEqual(orderDate, order.OrderDate);
			Assert.AreEqual(requiredDate, order.RequiredDate);
			Assert.AreEqual(shippingDate, order.ShippingDate);
			Assert.AreEqual(shippedTo, order.ShippedTo);
		}

		[Test]
		public void CreateOrderWithLinkedOrderLine()
		{
			long orderId = -1;
			long orderLineId = -1;

			CreateOrderWithOrderLines(Session, ref orderId, ref orderLineId);

			Order order = Session.Get<Order>(orderId);
			OrderLine orderLine = Session.Get<OrderLine>(orderLineId);

			Assert.That(order.OrderLines.Contains(orderLine));
			Assert.AreEqual(order, orderLine.Order);
		}

		[Test]
		public void DeleteOrderWithLinkedOrderLine()
		{
			long orderId = -1;
			long orderLineId = -1;

			CreateOrderWithOrderLines(Session, ref orderId, ref orderLineId);

			Session.Delete("from Order where OrderId = ?", orderId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<OrderLine>(orderLineId));
		}

		[Test]
		public void RemoveOrderLineFromOrder()
		{
			long orderId = -1;
			long orderLineId = -1;

			CreateOrderWithOrderLines(Session, ref orderId, ref orderLineId);

			Order order = Session.Get<Order>(orderId);
			OrderLine orderLine = Session.Get<OrderLine>(orderLineId);

			order.RemoveOrderLine(orderLine);

			Session.Update(order);
			Session.Flush();

			Assert.IsNull(Session.Get<OrderLine>(orderLineId));
		}
	}
}
using NHibernate;
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class RegionTests : NHibernateTest
	{
		private void CreateRegionWithTerritory(ISession session, ref long regionId, ref long territoryId)
		{
			Region region = new Region("MyRegion");
			Territory territory = new Territory("MyTerritory");

			region.AddTerritory(territory);

			session.Save(region);
			session.Flush();

			regionId = region.Id;
			territoryId = territory.Id;

			session.Evict(region);
			session.Evict(territory);
		}

		[Test]
		public void CreateRegion()
		{
			string name = "myRegion";
			Region region = new Region(name);

			Session.Save(region);
			Session.Flush();

			long id = region.Id;

			Session.Evict(region);

			region = Session.Get<Region>(id);
			Assert.AreEqual(name, region.Description);
		}

		[Test]
		public void CreateRegionWithLinkedTerritory()
		{
			long regionId = -1;
			long territoryId = -1;

			CreateRegionWithTerritory(Session, ref regionId, ref territoryId);

			Region region = Session.Get<Region>(regionId);
			Territory territory = Session.Get<Territory>(territoryId);

			Assert.That(region.Territories.Contains(territory));
			Assert.AreEqual(region, territory.Region);
		}

		[Test]
		public void DeleteRegionLinkedToTerritories()
		{
			long regionId = -1;
			long territoryId = -1;

			CreateRegionWithTerritory(Session, ref regionId, ref territoryId);

			Session.Delete("from Region where RegionId = ?", regionId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Territory>(territoryId));
		}

		[Test]
		public void RemoveTerritoryFromRegion()
		{
			long regionId = -1;
			long territoryId = -1;

			CreateRegionWithTerritory(Session, ref regionId, ref territoryId);

			Region region = Session.Get<Region>(regionId);
			Territory territory = Session.Get<Territory>(territoryId);

			region.RemoveTerritory(territory);

			Session.Save(region);
			Session.Flush();

			Session.Evict(territory);

			Assert.IsNull(Session.Get<Territory>(territoryId));
		}
	}
}
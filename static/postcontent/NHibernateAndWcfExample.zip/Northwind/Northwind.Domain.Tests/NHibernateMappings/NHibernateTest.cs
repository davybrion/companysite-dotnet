using NHibernate;
using NHibernate.Cfg;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	public abstract class NHibernateTest
	{
		private static ISessionFactory _sessionFactory;
		private ISession _session;
		private ITransaction _transaction;

		protected ISession Session
		{
			get { return _session; }
		}

		[SetUp]
		public void SetUp()
		{
			if (_sessionFactory == null)
			{
				Configuration configuration = new Configuration()
					.AddAssembly("Northwind.Domain");
				_sessionFactory = configuration.BuildSessionFactory();
			}

			_session = _sessionFactory.OpenSession();
			_transaction = _session.BeginTransaction();
		}

		[TearDown]
		public void TearDown()
		{
			_transaction.Rollback();
			_transaction.Dispose();
			_transaction = null;
			_session.Close();
			_session.Dispose();
			_session = null;
		}
	}
}
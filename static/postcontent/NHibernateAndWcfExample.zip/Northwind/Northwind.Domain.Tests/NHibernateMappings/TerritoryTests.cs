using NHibernate;
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class TerritoryTests : NHibernateTest
	{
		private void CreateTerritoryWithEmployee(ISession session,
		                                         ref long territoryId, ref long employeeid)
		{
			Region region = new Region("MyRegion");
			Territory territory = new Territory("MyTerritory");
			territory.Region = region;

			Employee employee = new Employee("Test1", "Test1");

			territory.AddEmployee(employee);

			session.Save(region);
			session.Save(territory);
			session.Flush();

			territoryId = territory.Id;
			employeeid = employee.Id;

			session.Evict(region);
			session.Evict(territory);
			session.Evict(employee);
		}

		[Test]
		public void CreateTerritory()
		{
			Region region = new Region("MyRegion");
			Territory territory = new Territory("MyTerritory");
			territory.Region = region;

			Session.Save(region);
			Session.Save(territory);
			Session.Flush();

			long territoryId = territory.Id;

			Session.Evict(region);
			Session.Evict(territory);

			territory = Session.Get<Territory>(territoryId);
			Assert.AreEqual("MyTerritory", territory.Description);
			Assert.AreEqual("MyRegion", territory.Region.Description);
		}

		[Test]
		public void CreateTerritoryWithLinkedEmployee()
		{
			long territoryId = -1;
			long employeeId = -1;

			CreateTerritoryWithEmployee(Session, ref territoryId, ref employeeId);

			Territory territory = Session.Get<Territory>(territoryId);
			Employee employee = Session.Get<Employee>(employeeId);

			Assert.That(territory.Employees.Contains(employee));
			Assert.That(employee.Territories.Contains(territory));
		}

		[Test]
		public void DeleteTerritoryWithLinkedEmployees()
		{
			long territoryId = -1;
			long employeeId = -1;

			CreateTerritoryWithEmployee(Session, ref territoryId, ref employeeId);

			Session.Delete("from Territory where TerritoryId = ?", territoryId, NHibernateUtil.String);
			Session.Flush();

			Assert.AreEqual(0, Session.Get<Employee>(employeeId).Territories.Count);
		}

		[Test]
		public void RemoveEmployeeFromTerritory()
		{
			long territoryId = -1;
			long employeeId = -1;

			CreateTerritoryWithEmployee(Session, ref territoryId, ref employeeId);

			Territory territory = Session.Get<Territory>(territoryId);
			Employee employee = Session.Get<Employee>(employeeId);

			territory.RemoveEmployee(employee);
			Session.Save(territory);
			Session.Flush();

			Session.Evict(territory);
			Session.Evict(employee);

			territory = Session.Get<Territory>(territoryId);
			employee = Session.Get<Employee>(employeeId);

			Assert.IsFalse(territory.Employees.Contains(employee));
			Assert.IsFalse(employee.Territories.Contains(territory));
		}
	}
}
using NHibernate;
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class ProductCategoryTests : NHibernateTest
	{
		private void CreateProductCategoryWithProduct(ISession session, ref long categoryId, ref long productId)
		{
			ProductCategory category = new ProductCategory("Name");
			Product product = new Product("Name");
			category.AddProduct(product);

			session.Save(category);
			session.Flush();

			categoryId = category.Id;
			productId = product.Id;

			session.Evict(product);
			session.Evict(category);
		}

		[Test]
		public void CreateProductCategory()
		{
			string name = "CategoryName";
			string description = "Category Description";

			ProductCategory productCategory = new ProductCategory();
			productCategory.Name = name;
			productCategory.Description = description;

			Session.Save(productCategory);
			Session.Flush();

			long id = productCategory.Id;

			Session.Evict(productCategory);

			productCategory = Session.Get<ProductCategory>(id);
			Assert.AreEqual(name, productCategory.Name);
			Assert.AreEqual(description, productCategory.Description);
		}

		[Test]
		public void CreateProductCategoryWithLinkedProduct()
		{
			long categoryId = -1;
			long productId = -1;

			CreateProductCategoryWithProduct(Session, ref categoryId, ref productId);

			ProductCategory category = Session.Get<ProductCategory>(categoryId);
			Product product = Session.Get<Product>(productId);

			Assert.That(category.Products.Contains(product));
			Assert.AreEqual(category, product.Category);
		}

		[Test]
		public void DeleteProductCategoryWithLinkedProduct()
		{
			long categoryId = -1;
			long productId = -1;

			CreateProductCategoryWithProduct(Session, ref categoryId, ref productId);

			Session.Delete("from ProductCategory where CategoryId = ?", categoryId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Product>(productId).Category);
		}

		[Test]
		public void RemoveProductFromProductCategory()
		{
			long categoryId = -1;
			long productId = -1;

			CreateProductCategoryWithProduct(Session, ref categoryId, ref productId);

			ProductCategory category = Session.Get<ProductCategory>(categoryId);
			Product product = Session.Get<Product>(productId);

			category.RemoveProduct(product);

			Session.Update(category);
			Session.Flush();

			Session.Evict(product);

			Assert.IsNull(Session.Get<Product>(productId).Category);
		}
	}
}
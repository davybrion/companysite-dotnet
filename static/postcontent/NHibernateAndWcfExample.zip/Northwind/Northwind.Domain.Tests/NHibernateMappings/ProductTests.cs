using NHibernate;
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class ProductTests : NHibernateTest
	{
		private void CreateProductWithOrderLine(ISession session, ref long productId, ref long orderLineId)
		{
			Customer customer = new Customer("MyCustomer");
			Order order = new Order(customer);
			Product product = new Product("ProductName");

			OrderLine orderLine = new OrderLine(order, product);
			orderLine.Discount = 1;
			orderLine.Quantity = 2;
			orderLine.UnitPrice = 5;

			order.AddOrderLine(orderLine);

			session.Save(customer);
			session.Save(product);
			session.Save(order);
			session.Flush();

			productId = product.Id;
			orderLineId = orderLine.Id;

			session.Evict(customer);
			session.Evict(product);
			session.Evict(order);
			session.Evict(orderLine);
		}

		[Test]
		public void CreateProduct()
		{
			Supplier supplier = new Supplier("MySupplier");
			ProductCategory category = new ProductCategory("MyCategory");

			string testString = "test";
			int testInt = 1;
			Product product = new Product();
			product.Supplier = supplier;
			product.Category = category;
			product.Discontinued = true;
			product.Name = testString;
			product.QuantityPerUnit = testString;
			product.ReorderLevel = testInt;
			product.UnitPrice = testInt;
			product.UnitsInStock = testInt;
			product.UnitsOnOrder = testInt;

			Session.Save(supplier);
			Session.Save(category);
			Session.Save(product);
			Session.Flush();

			long productId = product.Id;
			long supplierId = supplier.Id;
			long categoryId = category.Id;

			Session.Evict(product);
			Session.Evict(supplier);
			Session.Evict(category);

			product = Session.Get<Product>(productId);
			Assert.AreEqual(supplierId, product.Supplier.Id);
			Assert.AreEqual(categoryId, product.Category.Id);
			Assert.IsTrue(product.Discontinued);
			Assert.AreEqual(testString, product.Name);
			Assert.AreEqual(testString, product.QuantityPerUnit);
			Assert.AreEqual(testInt, product.ReorderLevel);
			Assert.AreEqual(testInt, product.UnitPrice);
			Assert.AreEqual(testInt, product.UnitsInStock);
			Assert.AreEqual(testInt, product.UnitsOnOrder);
		}

		[Test]
		[ExpectedException(typeof (ADOException))]
		public void DeleteProductLinkedToOrderLine()
		{
			long productId = -1;
			long orderLineId = -1;

			CreateProductWithOrderLine(Session, ref productId, ref orderLineId);

			// we shouldn't be able to delete a product that still has related orderlines
			Session.Delete("from Product where ProductId = ?", productId, NHibernateUtil.Int64);
			Session.Flush();
		}

		[Test]
		public void ProductContainsLinkedOrderLines()
		{
			long productId = -1;
			long orderLineId = -1;

			CreateProductWithOrderLine(Session, ref productId, ref orderLineId);

			Product product = Session.Get<Product>(productId);
			OrderLine orderLine = Session.Get<OrderLine>(orderLineId);

			Assert.That(product.OrderLines.Contains(orderLine));
			Assert.AreEqual(product, orderLine.Product);
		}
	}
}
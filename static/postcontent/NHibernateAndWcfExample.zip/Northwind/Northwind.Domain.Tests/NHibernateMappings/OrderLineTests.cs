using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class OrderLineTests : NHibernateTest
	{
		[Test]
		public void CreateOrderline()
		{
			int testInt = 1;

			Customer customer = new Customer("MyCustomer");
			Order order = new Order(customer);
			Product product = new Product("MyProduct");

			OrderLine orderLine = new OrderLine();
			orderLine.Order = order;
			orderLine.Product = product;
			orderLine.Discount = testInt;
			orderLine.Quantity = testInt;
			orderLine.UnitPrice = testInt;

			Session.Save(customer);
			Session.Save(order);
			Session.Save(product);
			Session.Save(orderLine);
			Session.Flush();

			long orderLineId = orderLine.Id;
			long orderId = order.Id;
			long productId = product.Id;

			Session.Evict(customer);
			Session.Evict(order);
			Session.Evict(orderLine);
			Session.Evict(product);

			orderLine = Session.Get<OrderLine>(orderLineId);
			Assert.AreEqual(orderId, orderLine.Order.Id);
			Assert.AreEqual(productId, orderLine.Product.Id);
			Assert.AreEqual(testInt, orderLine.Discount);
			Assert.AreEqual(testInt, orderLine.Quantity);
			Assert.AreEqual(testInt, orderLine.UnitPrice);
		}
	}
}
using NHibernate;
using Northwind.Domain.Entities;
using Northwind.Domain.ValueObjects;
using NUnit.Framework;

namespace Northwind.Domain.Tests.NHibernateMappings
{
	[TestFixture]
	public class SupplierTests : NHibernateTest
	{
		private void CreateSupplierWithProduct(ISession session, ref long supplierId, ref long productId)
		{
			Supplier supplier = new Supplier("Supplier");
			Product product = new Product("Product");
			supplier.AddProduct(product);

			session.Save(supplier);
			session.Flush();

			supplierId = supplier.Id;
			productId = product.Id;

			session.Evict(supplier);
			session.Evict(product);
		}

		[Test]
		public void CreateSupplierWithAllData()
		{
			Address address = new Address("t", "t", "t", "t", "t", "t", "t");
			string testString = "test";

			Supplier supplier = new Supplier();
			supplier.Address = address;
			supplier.CompanyName = testString;
			supplier.ContactName = testString;
			supplier.ContactTitle = testString;
			supplier.HomePage = testString;

			Session.Save(supplier);
			Session.Flush();

			long id = supplier.Id;

			Session.Evict(supplier);

			supplier = Session.Get<Supplier>(id);
			Assert.AreEqual(address, supplier.Address);
			Assert.AreEqual(testString, supplier.CompanyName);
			Assert.AreEqual(testString, supplier.ContactName);
			Assert.AreEqual(testString, supplier.ContactTitle);
			Assert.AreEqual(testString, supplier.HomePage);
		}

		[Test]
		public void CreateSupplierWithLinkedProduct()
		{
			long supplierId = -1;
			long productId = -1;

			CreateSupplierWithProduct(Session, ref supplierId, ref productId);

			Supplier supplier = Session.Get<Supplier>(supplierId);
			Product product = Session.Get<Product>(productId);

			Assert.That(supplier.Products.Contains(product));
			Assert.AreEqual(supplier, product.Supplier);
		}

		[Test]
		public void DeleteSupplierLinkedToProduct()
		{
			long supplierId = -1;
			long productId = -1;

			CreateSupplierWithProduct(Session, ref supplierId, ref productId);

			Session.Delete("from Supplier where SupplierId = ?", supplierId, NHibernateUtil.Int64);
			Session.Flush();

			Assert.IsNull(Session.Get<Product>(productId).Supplier);
		}

		[Test]
		public void RemoveProductFromSupplier()
		{
			long supplierId = -1;
			long productId = -1;

			CreateSupplierWithProduct(Session, ref supplierId, ref productId);

			Supplier supplier = Session.Get<Supplier>(supplierId);
			Product product = Session.Get<Product>(productId);

			supplier.RemoveProduct(product);

			Session.Update(supplier);
			Session.Flush();

			Session.Evict(product);

			Assert.IsNull(Session.Get<Product>(productId).Supplier);
		}
	}
}
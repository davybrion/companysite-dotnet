using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class TerritoryTests
	{
		[Test]
		public void Territory_AddEmployee_TerritoryContainsEmployee()
		{
			Territory territory = new Territory();
			Employee employee = new Employee();

			territory.AddEmployee(employee);

			Assert.That(territory.Employees.Contains(employee));
		}

		[Test]
		public void Territory_GetDescription_StripsExtraPadding()
		{
			Territory territory = new Territory();
			territory.Description = "blah ";
			Assert.AreEqual("blah", territory.Description);
		}

		[Test]
		public void Territory_RemoveEmployee_TerritoryDoesNotContainEmployee()
		{
			Territory territory = new Territory();
			Employee employee = new Employee();

			territory.AddEmployee(employee);
			territory.RemoveEmployee(employee);

			Assert.IsFalse(territory.Employees.Contains(employee));
		}
	}
}
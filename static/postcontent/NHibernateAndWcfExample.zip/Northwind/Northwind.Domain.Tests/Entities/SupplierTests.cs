using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class SupplierTests
	{
		[Test]
		public void Supplier_AddProduct_ParentAndChildKnowEachOther()
		{
			Supplier supplier = new Supplier();
			Product product = new Product();

			supplier.AddProduct(product);

			Assert.That(supplier.Products.Contains(product));
			Assert.AreEqual(supplier, product.Supplier);
		}

		[Test]
		public void Supplier_RemoveProduct_ParentAndChildNoLongerKnowEachOther()
		{
			Supplier supplier = new Supplier();
			Product product = new Product();

			supplier.AddProduct(product);
			supplier.RemoveProduct(product);

			Assert.IsFalse(supplier.Products.Contains(product));
			Assert.IsNull(product.Supplier);
		}
	}
}
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class RegionTests
	{
		[Test]
		public void Region_AddTerritory_ParentAndChildKnowEachOther()
		{
			Region region = new Region();
			Territory territory = new Territory();

			region.AddTerritory(territory);

			Assert.That(region.Territories.Contains(territory));
			Assert.AreEqual(region, territory.Region);
		}

		[Test]
		public void Region_GetDescription_StripsExtraPadding()
		{
			Region region = new Region();
			region.Description = "New Region ";
			Assert.AreEqual("New Region", region.Description);
		}

		[Test]
		public void Region_RemoveTerritory_ParentAndChildDontKnowEachOther()
		{
			Region region = new Region();
			Territory territory = new Territory();

			region.AddTerritory(territory);
			region.RemoveTerritory(territory);

			Assert.IsNull(territory.Region);
			Assert.IsFalse(region.Territories.Contains(territory));
		}
	}
}
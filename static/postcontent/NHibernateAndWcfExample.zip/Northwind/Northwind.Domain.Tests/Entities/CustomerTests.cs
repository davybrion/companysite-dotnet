using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class CustomerTests
	{
		[Test]
		public void Customer_AddOrder_ParentAndChildKnowEachOther()
		{
			Customer customer = new Customer();
			Order order = new Order();

			customer.AddOrder(order);

			Assert.That(customer.Orders.Contains(order));
			Assert.AreEqual(customer, order.Customer);
		}

		[Test]
		public void Customer_RemoveOrder_ParentAndChildNoLongerKnowEachOther()
		{
			Customer customer = new Customer();
			Order order = new Order();

			customer.AddOrder(order);
			customer.RemoveOrder(order);

			Assert.That(!customer.Orders.Contains(order));
			Assert.IsNull(order.Customer);
		}
	}
}
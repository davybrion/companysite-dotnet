using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class EmployeeTests
	{
		[Test]
		public void Employee_AddOrder_ParentAndChildKnowEachOther()
		{
			Employee employee = new Employee();
			Order order = new Order();

			employee.AddOrder(order);

			Assert.That(employee.Orders.Contains(order));
			Assert.AreEqual(employee, order.Employee);
		}

		[Test]
		public void Employee_AddSubordinate_ParentAndChildKnowEachOther()
		{
			Employee superior = new Employee();
			Employee subordinate = new Employee();

			superior.AddSubordinate(subordinate);

			Assert.That(superior.Subordinates.Contains(subordinate));
			Assert.AreEqual(superior, subordinate.Superior);
		}

		[Test]
		public void Employee_RemoveOrder_ParentAndChildNoLongerKnowEachOther()
		{
			Employee employee = new Employee();
			Order order = new Order();

			employee.AddOrder(order);
			employee.RemoveOrder(order);

			Assert.IsFalse(employee.Orders.Contains(order));
			Assert.IsNull(order.Employee);
		}

		[Test]
		public void Employee_RemoveSubordinate_ParentAndChildNoLongerKnowEachOther()
		{
			Employee superior = new Employee();
			Employee subordinate = new Employee();

			superior.AddSubordinate(subordinate);
			superior.RemoveSubordinate(subordinate);

			Assert.IsFalse(superior.Subordinates.Contains(subordinate));
			Assert.IsNull(subordinate.Superior);
		}
	}
}
using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class ProductCategoryTests
	{
		[Test]
		public void ProductCategory_AddProduct_ParentAndChildKnowEachOther()
		{
			ProductCategory category = new ProductCategory();
			Product product = new Product();

			category.AddProduct(product);

			Assert.That(category.Products.Contains(product));
			Assert.AreEqual(category, product.Category);
		}

		[Test]
		public void ProductCategory_RemoveProduct_ParentAndChildNoLongerKnowEachOther()
		{
			ProductCategory category = new ProductCategory();
			Product product = new Product();

			category.AddProduct(product);
			category.RemoveProduct(product);

			Assert.IsFalse(category.Products.Contains(product));
			Assert.IsNull(product.Category);
		}
	}
}
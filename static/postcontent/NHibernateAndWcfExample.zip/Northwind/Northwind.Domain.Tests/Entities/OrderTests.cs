using Northwind.Domain.Entities;
using NUnit.Framework;

namespace Northwind.Domain.Tests.Entities
{
	[TestFixture]
	public class OrderTests
	{
		[Test]
		public void Order_AddOrderLine_ParentAndChildKnowEachOther()
		{
			Order order = new Order();
			OrderLine orderLine = new OrderLine();

			order.AddOrderLine(orderLine);

			Assert.AreEqual(order, orderLine.Order);
			Assert.That(order.OrderLines.Contains(orderLine));
		}

		[Test]
		public void Order_RemoveOrderLine_ParentAndChildNoLongerKnowEachOther()
		{
			Order order = new Order();
			OrderLine orderLine = new OrderLine();

			order.AddOrderLine(orderLine);
			order.RemoveOrderLine(orderLine);

			Assert.IsFalse(order.OrderLines.Contains(orderLine));
			Assert.IsNull(orderLine.Order);
		}
	}
}
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Northwind.Domain
{
	[Serializable]
	public abstract class Entity<T>
	{
		private readonly long _id = -1;

		public virtual long Id
		{
			get { return _id; }
		}

		public virtual T Clone()
		{
			MemoryStream memoryStream = new MemoryStream();
			BinaryFormatter binaryFormatter = new BinaryFormatter();

			binaryFormatter.Serialize(memoryStream, this);
			memoryStream.Position = 0;
			return (T)binaryFormatter.Deserialize(memoryStream);
		}
	}
}
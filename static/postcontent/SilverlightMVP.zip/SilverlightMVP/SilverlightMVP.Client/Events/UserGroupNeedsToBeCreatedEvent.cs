using SilverlightMVP.Client.Infrastructure.Eventing;

namespace SilverlightMVP.Client.Events
{
	public class UserGroupNeedsToBeCreatedEvent : Event {}
}
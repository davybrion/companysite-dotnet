namespace SilverlightMVP.Client.Infrastructure.Eventing
{
	public abstract class Event {}
}
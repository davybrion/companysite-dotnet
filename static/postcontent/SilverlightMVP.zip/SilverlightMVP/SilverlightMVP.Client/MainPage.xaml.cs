﻿using System.Windows.Controls;

namespace SilverlightMVP.Client
{
	public partial class MainPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
